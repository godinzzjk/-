package com.zl.demo.entity;

/**
 * Created by Administrator on 2016/3/14.
 */
public class Employee {
    private int id;
    private String empname;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEmpname() {
        return empname;
    }

    public void setEmpname(String empname) {
        this.empname = empname;
    }
}
