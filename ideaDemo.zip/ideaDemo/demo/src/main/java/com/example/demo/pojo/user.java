package com.example.demo.pojo;

public class user {
    private Integer id;

    private String username;

    private String userclub;

    private String useraddress;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username == null ? null : username.trim();
    }

    public String getUserclub() {
        return userclub;
    }

    public void setUserclub(String userclub) {
        this.userclub = userclub == null ? null : userclub.trim();
    }

    public String getUseraddress() {
        return useraddress;
    }

    public void setUseraddress(String useraddress) {
        this.useraddress = useraddress == null ? null : useraddress.trim();
    }
}