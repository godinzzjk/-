package com.example.demo.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.example.demo.pojo.manager;
import com.example.demo.pojo.user;

public interface IUserDao {

	
	public manager login(@Param("name")String name,@Param("pwd")String pwd);
	public List<user> show();
	
}
