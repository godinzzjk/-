package com.example.demo.biz;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.IUserDao;
import com.example.demo.pojo.manager;
import com.example.demo.pojo.user;

@Service
public class UserBiz {

	@Autowired
	private IUserDao dao;
	
	public manager login(String name,String pwd){
		return dao.login(name, pwd);
	}
	public List<user> show(){
		return dao.show();
	}
	
	
}
