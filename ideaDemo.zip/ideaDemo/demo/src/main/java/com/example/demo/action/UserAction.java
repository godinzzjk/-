package com.example.demo.action;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo.biz.UserBiz;
import com.example.demo.pojo.manager;
import com.example.demo.pojo.user;

@Controller
public class UserAction {

	
	@Autowired
	private UserBiz biz;
	
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	@ResponseBody
	public manager login(String name,String pwd){
		return biz.login(name, pwd);
	}
	
	@RequestMapping(value = "/show", method = RequestMethod.POST)
	@ResponseBody
	public List<user> show(){
		return biz.show();
	}

	/**
	 * MVC:首页地址
	 * @param model
	 * @return
	 */
	@GetMapping("/toLogin")
	public String homeUrl(Model model) {
		return "test";
	}

	@GetMapping("/toIndex")
	public String toIndex(Model model) {
		return "index";
	}

	
}
